                <div class="row mb-3">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="contactDeaitl__head">
                                    <div class="contactDeaitl__userdata">
                                        <div class="contactDetail__userImg me-3">
                                            <img src="assets/images/contact-user.png" alt="">
                                        </div>
                                        
                                        <div class="contactDeaitl__Detal">
                                            <h6>John Rose <span>$2,744</span></h6>
                                            
                                            <div class="contactDeaitl__userContact">
                                                <a href="#" class="me-2">
                                                    <span class="material-symbols-outlined">sell</span>
                                                    +1-3172581477
                                                </a>
                                                <a href="#">
                                                    <span class="material-symbols-outlined">outgoing_mail</span>
                                                    johnnyrose1877@gmail.com
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="dealSummary__headBtn">
                                        <a href="#">
                                            Edit <span class="material-symbols-outlined">add_circle</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>