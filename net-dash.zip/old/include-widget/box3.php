                <div class="row my-2">
                    <div class="col-md-12">
                        <div class="card rounded-0">
                           <div class="card-body">
                              <div class="contactMag__card">
                                 <div class="contactMag__userDetail">
                                    <div class="contactMag__profile">
                                       <div class="contactMag__image">
                                          <img src="assets/images/contact-user.png" alt="">
                                       </div>
                                       <div class="contactMag__name">
                                          <h6>John Rose </h6>
                                          <p>
                                             <span class="material-symbols-outlined">avg_pace</span> Today at 4:09 Pm
                                          </p>
                                       </div>
                                    </div>
                                    <div class="contactMag__contact">
                                       <a href="tel:+1-3172581477">
                                          <span class="material-symbols-outlined">sell</span>+1-3172581477
                                       </a>
                                       <a href="mailto:johnnyrose1877@gmail.com">
                                          <span class="material-symbols-outlined">outgoing_mail</span>johnnyrose1877@gmail.com
                                       </a>
                                    </div>
                                 </div>

                                 <div class="contactMag__selectionBox">
                                    <div class="contactMag__selectionImage">
                                       <img src="assets/images/3.png" alt="">
                                    </div>
                                    <div class="contactMag__selectionDetails">
                                       <h6>
                                          Truhlar And Truhlar
                                       </h6>
                                       <p>
                                          <span class="material-symbols-outlined">avg_pace</span>Jul 27, 2023 07:56 PM
                                       </p>
                                    </div>
                                    <div class="contactMag__selectionArrow">
                                       <span class="material-symbols-outlined">keyboard_arrow_down</span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                    </div>
                </div>
         