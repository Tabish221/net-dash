google.load("visualization", {packages:["bar"]});
google.charts.load('current', {'packages': ['geochart'], 'mapsApiKey': 'AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY'});
google.charts.load('current', {packages: ['corechart', 'line']});
