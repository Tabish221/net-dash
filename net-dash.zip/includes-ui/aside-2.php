<aside class="closedBar hideAside">
    <div class="top-headerLeft">      
        <a href="#">
            <div class="header-profile">
                <div class="header-profileAvatar">
                    <img src="assets/images/admin.png" class="" alt="">
                </div>
                <div class="header-profileName">
                    <h6>Super Admin</h6>
                </div>
            </div>
    
            <div class="menu-Bar" style="display: none;">
                <span class="material-symbols-outlined">left_panel_close</span>
            </div>
        </a>
    </div>

    <?php include('aside-menu.php') ?>
</aside>