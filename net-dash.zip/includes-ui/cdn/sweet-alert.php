<!-- SWEET ALERT -->
<script src="assets/js/sweet-alert/sweetalert.js"></script>