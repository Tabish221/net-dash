<!-- High Chart -->
<script src="assets/js/chart/highcharts.js"></script>
<!-- High Chart Module -->
<script src="assets/js/chart/modules/funnel.js"></script>