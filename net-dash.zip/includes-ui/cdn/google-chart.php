<!-- Google Chart -->
<script src="assets/js/google-chart/chart.min.js"></script>
<script src="assets/js/google-chart/loader.js"></script>